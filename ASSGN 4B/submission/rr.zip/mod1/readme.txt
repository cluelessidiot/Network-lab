whenever a client logout ,the system will notifies all other client
